import React from 'react'
import Footer from './Footer'
// import FooterMenu from './FooterMenu'

export default function Index() {
    return (
        <>
            {/* <FooterMenu /> */}
            <Footer />
        </>
    )
}
