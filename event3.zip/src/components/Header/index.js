import React from "react";
import Navbar from "./Navbar"
// import TopNavbar from "./TopNavbar";

function Index() {
    return (
        <>
            {/* <TopNavbar /> */}
            <Navbar />
        </>
    )
}

export default Index