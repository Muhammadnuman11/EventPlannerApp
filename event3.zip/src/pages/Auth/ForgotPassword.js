import React from 'react'

export default function ForgotPassword() {
    return (
        <>
            <h1>ForgotPassword</h1>
        </>
    )
}
