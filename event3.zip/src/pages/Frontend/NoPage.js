import React from 'react'

export default function NoPage() {
  return (
    <>
      <h1>Page Not Found 404 ERROR</h1>
    </>
  )
}
